package servlets;

import servlets.Usuario;

public class Profesor extends Usuario {
    private String especialidad;  // Campo para almacenar la especialidad del profesor.

    // Constructor de la clase Profesor que recibe el nombre de usuario (login), la contraseña (password) y la especialidad.
    public Profesor(String login, String password, String especialidad) {
        super(login, password);  // Llama al constructor de la clase base 'Usuario' con el nombre de usuario y contraseña.
        this.especialidad = especialidad;  // Inicializa el campo 'especialidad' con el valor proporcionado.
    }

    // Método para obtener la especialidad del profesor.
    public String getEspecialidad() {
        return especialidad;
    }

    // Método para establecer la especialidad del profesor.
    public void setEspecialidad(String especialidad) {
        this.especialidad = especialidad;
    }
}



