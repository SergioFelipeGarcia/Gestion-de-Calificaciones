package servlets;
public class Nota {
    private String nombreAlumno;
    private String nombreProfesor;
    private String especialidad;
    private int nota;

    public Nota(String nombreAlumno, String nombreProfesor, String especialidad, int nota) {
        this.nombreAlumno = nombreAlumno;
        this.nombreProfesor = nombreProfesor;
        this.especialidad = especialidad;
        this.nota = nota;
    }

    // Agrega los getters y setters según sea necesario

    public String getNombreAlumno() {
        return nombreAlumno;
    }

    public String getNombreProfesor() {
        return nombreProfesor;
    }

    public String getEspecialidad() {
        return especialidad;
    }

    public int getNota() {
        return nota;
    }
}
