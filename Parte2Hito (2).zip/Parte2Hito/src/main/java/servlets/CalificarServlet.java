package servlets;


import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import jakarta.servlet.http.HttpSession;

@WebServlet("/CalificarServlet2")
public class CalificarServlet extends HttpServlet {
    private ArrayList<Nota> notas = new ArrayList<>(); // ArrayList para almacenar las notas
   
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Obtener los datos del formulario
        String nombreAlumno = request.getParameter("alumno");
        String nombreProfesor = request.getParameter("profesor");
        String especialidad = request.getParameter("especialidad");
        int nota = Integer.parseInt(request.getParameter("nota"));
        
        System.out.println("obtengo los datos del formulario");
       
        // Crear una nueva instancia de Nota con los datos recibidos
        Nota nuevaNota = new Nota(nombreAlumno, nombreProfesor, especialidad, nota);

        // Agregar la nueva nota al ArrayList
        notas.add(nuevaNota);
        
     // Mensaje para ver el resultado de los datos que estamos gurdando
        System.out.println("Nota guardada: Alumno: " + nombreAlumno + ", Profesor: " + nombreProfesor + ", Especialidad: " + especialidad + ", Nota: " + nota);
        
        // Guardamos el array en la sesion por que lo vamos a utlizar en mas sitios
        
        HttpSession session = request.getSession();
        session.setAttribute("notas", notas);

        // Redirigir a la página donde deseas mostrar las notas
        response.sendRedirect("DatosProfesor.jsp");
    }
}
