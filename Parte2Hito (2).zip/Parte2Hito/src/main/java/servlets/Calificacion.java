package servlets;

import servlets.Profesor;
import servlets.Alumno;

public class Calificacion {
    private int calificacionId;   // Campo para almacenar el Id de la calificación.
    private Profesor profesor;    // Campo para almacenar el profesor que calificó la asignatura.
    private Alumno alumno;        // Campo para almacenar el alumno al que se le otorga la calificación.
    private String asignatura;    // Campo para almacenar el nombre de la asignatura.
    private int nota;             // Campo para almacenar la nota, un valor entre 0 y 100.

    // Constructor de la clase Calificacion que recibe un Id, un profesor, un alumno, una asignatura y una nota.
    public Calificacion(int calificacionId, Profesor profesor, Alumno alumno, String asignatura, int nota) {
        this.calificacionId = calificacionId;
        this.profesor = profesor;
        this.alumno = alumno;
        this.asignatura = asignatura;
        this.nota = nota;
    }

    // Métodos para obtener y establecer el Id de la calificación.
    public int getCalificacionId() {
        return calificacionId;
    }

    public void setCalificacionId(int calificacionId) {
        this.calificacionId = calificacionId;
    }

    // Métodos para obtener y establecer el profesor que calificó la asignatura.
    public Profesor getProfesor() {
        return profesor;
    }

    public void setProfesor(Profesor profesor) {
        this.profesor = profesor;
    }

    // Métodos para obtener y establecer el alumno al que se otorga la calificación.
    public Alumno getAlumno() {
        return alumno;
    }

    public void setAlumno(Alumno alumno) {
        this.alumno = alumno;
    }

    // Método para obtener el nombre de la asignatura.
    public String getAsignatura() {
        return asignatura;
    }

    // Método para establecer el nombre de la asignatura.
    public void setAsignatura(String asignatura) {
        this.asignatura = asignatura;
    }

    // Método para obtener la nota.
    public int getNota() {
        return nota;
    }

    // Método para establecer la nota.
    public void setNota(int nota) {
        this.nota = nota;
    }

    // Método toString que devuelve una representación en forma de cadena de la calificación.
    @Override
    public String toString() {
        return "ID de Calificación: " + calificacionId + ", Asignatura: " + asignatura + ", Nota: " + nota + " - Calificado por " + this.profesor.getLogin();
    }
}
