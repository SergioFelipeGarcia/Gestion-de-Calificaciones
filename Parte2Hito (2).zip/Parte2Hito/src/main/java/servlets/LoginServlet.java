package servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.List;

import java.util.ArrayList;
import java.util.HashMap;

 /** * Servlet implementation class LoginServlet */

public class LoginServlet extends HttpServlet {
    private Escuela escuela;

    public void init() throws ServletException { // INIT OJO - se llama una sola vez cuando el servlet se crea por primera vez o se inicializa.
        escuela = new Escuela(); // Inicializa el objeto Escuela
   
        getServletContext().setAttribute("miEscuela", escuela); // Almacena la instancia de Escuela en el contexto de la aplicación
    
        // Asi, puedo  acceder a esta instancia de Escuela desde cualquier servlet o página JSP
        // en tu aplicación utilizando getServletContext().getAttribute("miEscuela") Por si acaso.
            
    }

    // Proceso los datos del formulario de Login
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
	        String login = request.getParameter("login");
	        String password = request.getParameter("password");
     

        // Utiliza el objeto Escuela para verificar las credenciales
        HashMap<String, Usuario> usuarios = escuela.getUsuarios();
        Usuario usuario = usuarios.get(login);

        if (usuario != null && usuario.getPassword().equals(password)) {
            // Verifica si el usuario es un profesor
            if (usuario instanceof Profesor) {
                
            // Guarda el usuario en la sesión
                HttpSession session = request.getSession();
                session.setAttribute("usuario", usuario);
             // Obtiene la especialidad del profesor
                String especialidadProfesor = ((Profesor) usuario).getEspecialidad();
                session.setAttribute("especialidad", especialidadProfesor);
               
               
                
                // Obtiene todos los alumnos de la escuela
                List<String> loginsAlumnos = new ArrayList<>();

	             // Filtra los usuarios para obtener solo los alumnos y guardar sus logins
	             for (Usuario tipoAlumno : usuarios.values()) {
	                 if (usuario instanceof Alumno) {
	                     Alumno alumno = (Alumno) usuario;
	                     loginsAlumnos.add(alumno.getLogin());
	                 }
	             }
                
	          // Guarda el ArrayList loginsAlumnos como atributo de sesión
	             session.setAttribute("loginsAlumnos", loginsAlumnos);
                
                // Redirige a la página de profesor, donde podra ver a todos los alumnos y seleccionar al que calificar
                response.sendRedirect("DatosProfesor.jsp");
                
            } else if (usuario instanceof Alumno) {
                // Si el usuario es un alumno, redirige a la página de perfil del alumno, donde podrá ver sus notas
            	  HttpSession session = request.getSession();
                  session.setAttribute("usuario", usuario);
                  
                response.sendRedirect("VerperfilAlumno.jsp");
            }
        } else {
            // La autenticación falló, muestra un mensaje de error
            request.setAttribute("errorMessage", "Credenciales inválidas. Inténtalo de nuevo.");
            request.getRequestDispatcher("index.jsp").forward(request, response);
        }
    }
}



    

