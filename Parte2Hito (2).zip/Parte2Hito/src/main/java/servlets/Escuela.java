package servlets;

import java.util.HashMap;

public class Escuela {
    private HashMap<String, Usuario> usuarios;

    public Escuela() {
        super();
        this.usuarios = new HashMap<String, Usuario>();
        // Agrega aquí la lógica para crear profesores y alumnos predeterminados
        nuevoProfesor("Pepe", "1234", "Matemáticas, física");
        nuevoProfesor("Juan", "1234", "Informática");
        nuevoAlumno("Alicia", "2345");
        nuevoAlumno("Miguel", "2345");
    }

    // El método getUsuarios() es un método de acceso en la clase Escuela
    // que se utiliza para obtener el HashMap de usuarios. Su función es
    // proporcionar acceso a la colección de usuarios almacenada en la instancia de la clase Escuela.

    public HashMap<String, Usuario> getUsuarios() {
        return usuarios;
    }

    public void nuevoProfesor(String login, String password, String especialidad) {
        Profesor profesor = new Profesor(login, password, especialidad);
        usuarios.put(login, profesor);
    }

    public void nuevoAlumno(String login, String password) {
        Alumno alumno = new Alumno(login, password);
        usuarios.put(login, alumno);
    }
}

