package consola;

import java.util.ArrayList;

public class Alumno extends Usuario {
    private ArrayList<Calificacion> calificaciones; // Campo para almacenar las calificaciones del alumno.

    // Constructor de la clase Alumno que recibe el nombre de usuario (login) y la contraseña (password).
    public Alumno(String login, String password) {
        super(login, password);  // Llama al constructor de la clase base 'Usuario' con el nombre de usuario y contraseña.
        calificaciones = new ArrayList<Calificacion>();  // Inicializa la lista de calificaciones como una nueva lista vacía.
    }

    // Método para obtener la lista de calificaciones del alumno.
    public ArrayList<Calificacion> getCalificaciones() {
        return calificaciones;
    }

    // Método para agregar una calificación para el alumno.
    public void calificar(Profesor p, String asignatura, int nota) {
        this.calificaciones.add(new Calificacion(p, asignatura, nota)); // Crea una nueva calificación y la agrega a la lista de calificaciones.
    }

    // Método toString que devuelve una representación en forma de cadena del alumno y sus calificaciones.
    @Override
    public String toString() {
        String calificacionesStr = "";
        for (Calificacion c : this.getCalificaciones()) {
            calificacionesStr += c.toString() + "\n";  // Convierte cada calificación a cadena y las concatena.
        }
        return "Alumno: " + this.getLogin() + "\n" + calificacionesStr;  // Devuelve una representación en forma de cadena del alumno y sus calificaciones.
    }
}
