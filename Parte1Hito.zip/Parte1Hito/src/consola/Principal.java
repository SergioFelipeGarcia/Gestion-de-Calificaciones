package consola;

import java.util.Scanner;

public class Principal {

	public static void main(String[] args) {
		// Crear una instancia de la clase Escuela.
		Escuela e = new Escuela();
		// Crear un objeto Scanner para la entrada de usuario.
		Scanner lector = new Scanner(System.in);
		
		// Agregar profesores y alumnos a la escuela.
		e.nuevoProfesor("Pepe", "1234", "Matemáticas, física");
		e.nuevoProfesor("Juan", "1234", "Informática");
		e.nuevoAlumno("Alicia", "2345");
		e.nuevoAlumno("Miguel", "2345");

		// Declarar variables de usuario, profesor y alumno.
		Usuario usuario;
		Profesor profesor;
		Alumno alumno;

		// Solicitar al usuario introducir el nombre del profesor.
		System.out.println("VAMOS A AÑADIR UNA CALIFICACIÓN");
		System.out.print("Introduce el nombre del profesor: ");
		String p = lector.nextLine();

		// Obtener un usuario de la escuela según el nombre introducido.
		usuario = e.getUsuarios().get(p);

		// Comprobar si el usuario existe y si es un profesor.
		if (usuario == null) {
			System.out.println("El usuario con login " + p + " no está registrado");
			lector.close();
			return;
		} else if (usuario instanceof Profesor) {
			profesor = (Profesor) usuario;
			System.out.println(profesor.getLogin() + " es un profesor");
		} else {
			System.out.println(usuario.getLogin() + " no es un profesor");
			lector.close();
			return;
		}

		// Solicitar al usuario introducir el nombre del alumno.
		System.out.print("Introduce el nombre del alumno: ");
		String a = lector.nextLine();

		// Obtener un usuario de la escuela según el nombre introducido.
		usuario = e.getUsuarios().get(a);

		// Comprobar si el usuario existe y si es un alumno.
		if (usuario == null) {
			System.out.println("El usuario con login " + a + " no está registrado");
			lector.close();
			return;
		} else if (usuario instanceof Alumno) {
			alumno = (Alumno) usuario;
			System.out.println(alumno.getLogin() + " es un alumno");
		} else {
			System.out.println(usuario.getLogin() + " no es un alumno");
			lector.close();
			return;
		}

		String continuar = "S";
		do {
			// Solicitar información sobre una asignatura y una nota.
			System.out.print("Introduce el nombre de la asignatura: ");
			String asig = lector.nextLine();
			System.out.print("Introduce la nota (0-100): ");
			int nota = lector.nextInt();
			lector.nextLine(); // Limpiar el buffer.

			// Calificar al alumno en una asignatura por parte del profesor.
			alumno.calificar(profesor, asig, nota);

			// Preguntar si el usuario quiere añadir más calificaciones.
			System.out.print("¿Quieres añadir más calificaciones (S/N)? ");
			continuar = lector.nextLine();
		} while (continuar.toUpperCase().equals("S"));

		// Imprimir la información del alumno.
		System.out.println(alumno);

		// Cerrar el objeto Scanner.
		lector.close();
	}
}
