package consola;

public class Usuario {
    private String login;      // Campo para almacenar el nombre de usuario.
    private String password;   // Campo para almacenar la contraseña.

    // Constructor de la clase Usuario que recibe el nombre de usuario (login) y la contraseña (password).
    public Usuario(String login, String password) {
        super();  // Llama al constructor de la clase base (Object).
        this.login = login;    // Inicializa el campo 'login' con el valor proporcionado.
        this.password = password;  // Inicializa el campo 'password' con el valor proporcionado.
    }

    // Método para obtener el nombre de usuario.
    public String getLogin() {
        return login;
    }

    // Método para establecer el nombre de usuario.
    public void setLogin(String login) {
        this.login = login;
    }

    // Método para obtener la contraseña.
    public String getPassword() {
        return password;
    }

    // Método para establecer la contraseña.
    public void setPassword(String password) {
        this.password = password;
    }
}