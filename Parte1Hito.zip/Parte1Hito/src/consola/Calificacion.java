package consola;

public class Calificacion {
    private Profesor profesor;    // Campo para almacenar el profesor que calificó la asignatura.
    private String asignatura;    // Campo para almacenar el nombre de la asignatura.
    private int nota;             // Campo para almacenar la nota, un valor entre 0 y 100.

    // Constructor de la clase Calificacion que recibe un profesor, una asignatura y una nota.
    public Calificacion(Profesor profesor, String asignatura, int nota) {
        super();  // Llama al constructor de la clase base (Object).
        this.profesor = profesor;    // Inicializa el campo 'profesor' con el profesor proporcionado.
        this.asignatura = asignatura; // Inicializa el campo 'asignatura' con la asignatura proporcionada.
        this.nota = nota;             // Inicializa el campo 'nota' con la nota proporcionada.
    }

    // Método para obtener el profesor que calificó la asignatura.
    public Profesor getProfesor() {
        return profesor;
    }

    // Método para establecer el profesor que calificó la asignatura.
    public void setProfesor(Profesor profesor) {
        this.profesor = profesor;
    }

    // Método para obtener el nombre de la asignatura.
    public String getAsignatura() {
        return asignatura;
    }

    // Método para establecer el nombre de la asignatura.
    public void setAsignatura(String asignatura) {
        this.asignatura = asignatura;
    }

    // Método para obtener la nota.
    public int getNota() {
        return nota;
    }

    // Método para establecer la nota.
    public void setNota(int nota) {
        this.nota = nota;
    }

    // Método toString que devuelve una representación en forma de cadena de la calificación.
    @Override
    public String toString() {
        return "Asignatura: " + asignatura + ", Nota: " + nota + " - Calificado por " + this.profesor.getLogin();
    }
}
