package consola;

import java.util.TreeMap;

public class Escuela {
    private TreeMap<String, Usuario> usuarios;

    // Constructor de la clase Escuela.
    public Escuela() {
        super();  // Llama al constructor de la clase base (Object).
        // TreeMap llamado 'usuarios' para almacenar usuarios,
        // donde la clave es el 'login' (nombre de usuario) y el valor es un objeto 'Usuario'.
        this.usuarios = new TreeMap<String, Usuario>();
    }

    // Método para agregar un nuevo profesor a la escuela.
    public void nuevoProfesor(String login, String password, String especialidad) {
        // Crea una instancia de la clase 'Profesor' con los datos proporcionados.
        Profesor profesor = new Profesor(login, password, especialidad);
        // Almacena al profesor en el TreeMap 'usuarios' utilizando su nombre de usuario como clave.
        usuarios.put(login, profesor);
    }

    // Método para agregar un nuevo alumno a la escuela.
    public void nuevoAlumno(String login, String password) {
        // Crea una instancia de la clase 'Alumno' con los datos proporcionados.
        Alumno alumno = new Alumno(login, password);
        // Almacena al alumno en el TreeMap 'usuarios' utilizando su nombre de usuario como clave.
        usuarios.put(login, alumno);
    }

    // Método para obtener la colección de usuarios de la escuela.
    public TreeMap<String, Usuario> getUsuarios() {
        return usuarios;
    }
}